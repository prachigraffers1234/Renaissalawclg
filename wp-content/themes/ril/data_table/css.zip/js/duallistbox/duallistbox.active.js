(function ($) {
 "use strict";
 
	$('.dual_select').bootstrapDualListbox({
			selectorMinimalHeight: 160
		});

 
})(jQuery); 