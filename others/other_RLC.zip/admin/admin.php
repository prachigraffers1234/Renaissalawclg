
<div class="container">
  <h2 class="align_center">Login successfully !!!</h2>

  <div class="alert alert-success align_center">
    <strong> Welcome <?php echo ucfirst($_SESSION['login_user']); ?> </strong>
  </div>

</div>
