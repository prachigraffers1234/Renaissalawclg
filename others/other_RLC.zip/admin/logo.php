<div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-4 logo align_center">
        <a href="index.php"><img src="image/logo.png"></a>
      </div>
    </div>
</div>
<hr>
