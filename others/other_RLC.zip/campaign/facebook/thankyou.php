<?PHP   
session_start();
$form_name = $_SESSION['form_name1'];
    if($form_name == "download-brochure-form")
    { 
/*    echo $form_name;
    echo $brochure_name;
    die();*/
        echo '<meta http-equiv="refresh" content="2;URL=downloadbrochure.php">' ;
    }    
    else if($form_name == "download-pdf-guide-form")
    { 
        echo '<meta http-equiv="refresh" content="2;URL=downloadbrochure1.php">' ;
    }    
?>


<!--
    <div class="container-fluid div-form">
        <div class="container">
        <div class="row div_thanks">
            <h2><label>THANK YOU!</label></h2>
            <p>
               For sharing your details with us. 
               Our Team will get back to you shortly.
            </p>
        </div>
        </div>
    </div>

        <div class="relative">
        <div class="box div_thanks">
            <div class="div_contact text-center">
                <h2><label>THANK YOU!</label></h2>
                <p>
                   For sharing your details with us. 
                   Our Team will get back to you shortly.
                </p>
            </div> 
        </div>
        </div>
-->


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Renaissance Law College</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="css/bootstrap.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css" />
    
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/validation.js"></script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '272036433308496');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=272036433308496&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

</head>
<body>
<script>
  fbq('track', 'Lead');
</script>

    <div class="sticky_form">
        <div class="relative">
        <div class="box div_thanks">
            <div class="div_contact text-center">
                <h2><label>THANK YOU!</label></h2>
                <p>
                   For sharing your details with us. 
                   Our Team will get back to you shortly.
                </p>
            </div> 
        </div>
        </div>
    </div> 
    
<!-------------------------- #BANNER -------------------------->
    <div class="container-fluid">
        <div class="row">              
            <div id="myCarousel" class="carousel slide" data-ride="carousel">                   
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                      <img src="img/banner_1.jpg" alt="isbr_mba" class="visible-sm visible-md visible-lg " />
                      <img src="img/banner_xs.jpg" alt="isbr_mba" class="visible-xs" />
                    </div>
<!--                    <div class="item">
                      <img src="img/banner_2.jpg" alt="isbr_mba" />
                    </div>-->
                    
        
<!-------------------------- #FORM -------------------------->
    <div class="div_form">
        <!--<div class="row ">-->
            <div class="col-sm-5 col-sm-offset-4 absolute_banner_text text-center">
                <img src="img/logo.gif" alt="Renaissance" class="logo" />
                <h2>EXPLORE DIVERSE POSSIBILITES<br> IN THE FIELD OF LAW!</h2>
                <h3><label>BBA LLB | BA LLB | BCOM LLB</label></h3>
                <!--<div class="bg_blinker">-->
                <h3 class="blinker1 visible-xs visible-sm">Admission Open for 2018-19</h3>
                <!--</div>-->
            </div>
            
            <div class="col-sm-3">
            <div class="col-sm-12 bg_color">
                <h2>Apply Here</h2>
                <div class="col-sm-12 padding_20">                    
                      <form class="form-horizontal" method="post" id="conform" name="conform" action="mail.php" onSubmit="return validate_form()">
                        <input type="hidden" name="formname" value="top-form"/>   
                        <div class="form-group col-sm-12">
                            <input id="name" name="name" type="text" placeholder="Name" class="form-control" required />
                            <p class="error_msg" id="error_name"></p>
                        </div>
                        <div class="form-group col-sm-12">
                            <input id="mobile" name="mobile"  type="text" placeholder="Mobile" maxlength="10" class="form-control" required />
                            <p class="error_msg" id="error_mobile"></p>
                        </div>
                        <div class="form-group col-sm-12">
                            <input id="email" name="email" type="text" placeholder="Email ID" class="form-control" required />
                            <p class="error_msg" id="error_email"></p>
                        </div>
                        <div class="form-group col-sm-12">
                            <input id="city" name="city" type="text" placeholder="City" class="form-control" required="">
                            <p class="error_msg" id="error_city"></p>  
                        </div>
                        <div class="form-group col-sm-12">
                            <select class="form-control" name="project" id="project">
                            <option value="0" selected="true" disabled="disabled">Select Courses</option>
                            <option value="BBA LLB">BBA LLB</option>
                            <option value="BCOM LLB">BCOM LLB</option>
                            <option value="BA LLB">BA LLB</option>
                            </select>
                            <p class="error_msg" id="error_project"></p>
                        </div>
                        <div class="form-group col-sm-12 text-center">
                            <input type="submit" name="submit" id="submit" value="SUBMIT" class="form-control" />
                        </div> 
                      </form>
                </div>
            </div>
            
            <div class="col-sm-12 bg_blinker visible-md visible-lg">
                <h3 class="blinker1">Admission Open for 2018-19</h3>
            </div>
            </div>
        <!--</div>-->
    </div>
<!-------------------------- /#FORM -------------------------->
                    
                    
                </div>
              <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev" >
                <span class="" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                <span class="" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a> 
                

                
                
            </div>
        </div>
    </div>
<!-------------------------- /#BANNER -------------------------->
    
<!-------------------------- #ABOUT -------------------------->
    <div class="containr_fluid">
    <div class="container div_about">
        <div class="row padding_20">
            <h3 class="padding_bottom_10">About Renaissance Law College</h3>
            <div class="col-sm-10 col-sm-offset-1">
            <p>
                Renaissance Law College located in Indore, the commercial capital of Madhya Pradesh. It inherits the concept of Gurukul. It is a vibrant heritage of the past & worked on the theory of targeted skill oriented educational approach, where a student was trained in his/her naturally inclined field of interest & equipped with skills-set that would help him/her in future life. Same thought is being adopted at renaissance & here different sets of courses are allotted to students according to their natural inclination & that too after a comprehensive counseling session.
            </p>
            </div>
        </div>
    </div>
    </div>
<!-------------------------- /#ABOUT -------------------------->
    
    
<!-------------------------- #ADVISORY BOARD -------------------------->
    <div class="containr_fluid div_board">
    <div class="container">
        <div class="row text-cente padding_20">
            <div class="col-sm-12 col-md-12  div_outcome">
                <h3 class="padding_bottom_30">Program Highlights</h3>
                
                <div class="col-md-4">
                <h4>BA. LL. B</h4>
                <ul>
                    <li>CLAT Affiliated College.</li>
                    <li>Approved by the Bar Council of India.</li>
                    <li>5 Year Integrated Programs.</li>
                    <li>The Only Law College having a Tie-up with National Law School of India University (Bangalore).</li>
                    <li>Internship opportunities with Biggest Law Firm In India, like Singhania & Co.| RLEK | A & S Legal Partners| Sharma Associates | Laxyo Energy Ltd. & many more.</li>
                    <li>Extracurricular Clubs & Programs.</li>
                    <li>Opportunities to interact with legal professionals.</li>
                </ul>   
                </div>
                <div class="col-md-4">
                <h4>BBA. LL. B</h4>
                <ul>
                    <li>The Only Law College having a Tie-up with National Law School of India University (Bangalore).</li>
                    <li>Internship opportunities with Biggest Law Firm In India, like Singhania & Co.| RLEK | A & S Legal Partners| Sharma Associates | Laxyo Energy Ltd. & many more.</li>
                    <li>CLAT Affiliated College.</li>
                    <li>Approved by the Bar Council of India.</li>
                    <li>5 Year Integrated Programs.</li>
                    <li>Academic Curriculum infused with law & justice themes.</li>
                    <li>Opportunities to interact with legal professionals.</li>
                </ul>   
                </div>
                <div class="col-md-4">
                <h4>B.Com. LL. B</h4>
                <ul>
                    <li>5 Year Integrated Programs.</li>
                    <li>Extracurricular clubs and programs.</li>
                    <li>Weekly brainstorming sessions.</li>
                    <li>Opportunities to interact with legal professionals.</li>
                    <li>The Only Law College having a Tie-up with National Law School of India University (Bangalore).</li>
                    <li>Internship opportunities with Biggest Law Firm In India, like Singhania & Co.| RLEK | A & S Legal Partners| Sharma Associates | Laxyo Energy Ltd. & many more.</li>
                    <li>CLAT Affiliated College.</li>
                    <li>Approved by the Bar Council of India.</li>
                    <li>Academic Curriculum infused with law & justice themes.</li>
                </ul>   
                </div>


            </div>
        </div>
    </div>
    </div>
<!-------------------------- /#ADVISORY BOARD -------------------------->

    
<!-------------------------- #Workshops -------------------------->
    <div class="containr_fluid">
    <div class="container div_about">
        <div class="row padding_20">
            <h3 class="padding_bottom_30">Renaissance Law College, Indore conducted Workshops on:</h3>
            <div class="col-sm-6 col-md-6">
                <ul>
                    <li>Workshop On Media Law</li>
                    <li>Workshop On Cyber Law</li>
                </ul>
            </div>
            <div class="col-sm-6 col-md-6">
                <ul>
                    <li>
                        Workshop On Contemporary Law
                        <ul class="no_bullet">
                            <li>A Workshop on “Contemporary Law” has been conducted by Vice Chancellor & Senior faculty members of “National Law School of India University” (NLSIU) & Certificate of participation was also issued by NLSIU</li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    </div>
<!-------------------------- /#Workshops -------------------------->
    
<!-------------------------- #Achievements -------------------------->
    <div class="containr_fluid">
    <div class="container div_about">
        <div class="row padding_20">
            <h3 class="padding_bottom_30">Achievements</h3>
            <div class="col-sm-6 col-md-6">
                <ul>
                    <li>Students published & presented a paper titled "Hindrances in Swift Mechanism of Justice and Legal Aid" in National Conference on Legal Education at VIT, Chennai</li>
                    <li>Students participated in an internship under Cyber Forensic Cell at National Law School of India University, Bangalore</li>
                </ul>
            </div>
            <div class="col-sm-6 col-md-6">
                <ul>
                    <li>Students participated & won best speaker award at 3rd International Moot Court Competition at Vivekananda Institute of Professional Studies</li>
                    <li>Students participated & secured top positions as speakers & researchers in 5th Paras Divas International Energy Law Moot Court Competition at University of Petroleum and Energy Studies, Dehradun</li>
                </ul>
            </div>
        </div>
    </div>
    </div>
<!-------------------------- /#Achievements -------------------------->

    
	
<!-------------------------- #FOOTER -------------------------->
    <div class="container-fluid div_footer">
        <div class="container">
            <div class="row text-right">
                <p class="no_margin">Designed By - InnoServ Digital</p>
            </div>
        </div>	
    </div>
<!-------------------------- /#FOOTER -------------------------->    
<!--
<script>
  $('.carousel').carousel({
   interval: 15000
  });
 </script>
-->

<script type="text/javascript">
    $(document).ready(function(){
        $(".slide-toggle").click(function(){
            $(".box").animate({
                width: "toggle"
            });
        });
    });
</script>

</body>
</html>






































