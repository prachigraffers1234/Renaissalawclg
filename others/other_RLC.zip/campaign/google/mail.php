<?PHP namespace SendGrid; ?>
<?PHP
require_once('sendgrid-php/sendgrid-php.php');

if(isset($_POST['submit']))
{
    ob_start();
    session_start();

    $form_name = $_POST['formname'];
    $_SESSION['form_name1'] = $form_name;

    $brochure_name = $_POST['brochure'];
    $_SESSION['brochure_name1'] = $brochure_name;

/*    echo $form_name;
    echo $brochure_name;
    die();*/

    helloEmail();
    header('location: thankyou.php');
    exit();
    ob_end_flush();
}

function helloEmail()
{
    $name = ($_POST['name']);
    $mobile = ($_POST['mobile']);
    $email = ($_POST['email']);
    $city = ($_POST['city']);
    $project = ($_POST['project']);
//    $querymsg = $query = $datemsg = $date = "";


    $subject = "Google | RCCM Law | Enquiry | ";
    $lp_name = "Google | RCCM Law";
    $lp_link = "http://renaissancelawcollege.com/campaign/google/";

    if($_POST['formname'] == "top-form")
    {
        $subject.="Top Form";
        $form_name = "Top Form";
    }
    else if($_POST['formname'] == "side-form")
    {
        $subject.="Side Form";
        $form_name = "Side Form";
    }
    else if($_POST['formname'] == "download-brochure-form")
    {
        $subject.="Download Brochure Form";
        $form_name = "Download Brochure Form";
    }
    else if($_POST['formname'] == "download-pdf-guide-form")
    {
        $subject.="Download PDF Guide Form";
        $form_name = "Download PDF Guide Form";
    }
    else if($_POST['formname'] == "apply-now-form")
    {
        $subject.="Get More Details Form";
        $form_name = "Get More Details Form";
    }
    else if($_POST['formname'] == "schedule-site-visit-form")
    {
        $subject.="Schedule Site Visit";
        $form_name = "Schedule Site Visit";

        $datemsg = $_POST['date'];

        $date ="<tr><td style='border:1px solid #666;border-collapse:collapse;'><strong>Query</strong> </td><td style='border:1px solid #666;border-collapse:collapse;'>" . trim($datemsg) . "</td></tr>";
    }
    else if($_POST['formname'] == "Ask-your-query-form")
    {
        $subject.="Consult Now Form";
        $form_name = "Consult Now Form";

        $querymsg = $_POST['query'];

        $query ="<tr><td style='border:1px solid #666;border-collapse:collapse;'><strong>Query</strong> </td><td style='border:1px solid #666;border-collapse:collapse;'>" . trim($querymsg) . "</td></tr>";
    }


    $message = '<html><body>';
    $message .= '<table rules="all" style="border:1px solid #666;" cellpadding="10">';
    $message .= "<tr><td style='border:1px solid #666;border-collapse:collapse;'><strong>Name </strong> </td><td style='border:1px solid #666;border-collapse:collapse;'>" . trim($name) . "</td></tr>";
    $message .= "<tr><td style='border:1px solid #666;border-collapse:collapse;'><strong>Contact </strong> </td><td style='border:1px solid #666;border-collapse:collapse;'>" . trim($mobile) . "</td></tr>";
    $message .= "<tr><td style='border:1px solid #666;border-collapse:collapse;'><strong>Email Id </strong> </td><td style='border:1px solid #666;border-collapse:collapse;'>" . trim($email) . "</td></tr>";
    $message .= "<tr><td style='border:1px solid #666;border-collapse:collapse;'><strong>City  </strong> </td><td style='border:1px solid #666;border-collapse:collapse;'>" . trim($city) . "</td></tr>";
    $message .= "<tr><td style='border:1px solid #666;border-collapse:collapse;'><strong>Selected Course </strong> </td><td style='border:1px solid #666;border-collapse:collapse;'>" . trim($project) . "</td></tr>";
    $message .= $query;
    /*$message .= $date;*/
    $message .= "</table>";
    $message .= "</body></html>";

    $body = $message;

    $from = new Email("RCCM Law Enquiry", "innoserv-dm@renaissancelawcollege.com");
    $subject = $subject;
    
/*    $to = new Email(null, "shruti.jathar@innoserv.co.in");
    $content = new Content("text/html", "$body");
    $mail = new Mail($from, $subject, $to, $content);*/
    
    $to = new Email(null, "rccm.university2019@gmail.com");
    $content = new Content("text/html", "$body");
    $mail = new Mail($from, $subject, $to, $content);

    $cc = new Email(null, "manoj.rathod@innoserv.co.in");
    $mail->personalization[0]->addCC($cc);

    $cc = new Email(null, "shirish.deshpande@innoserv.co.in");
    $mail->personalization[0]->addCC($cc);

    $cc = new Email(null, "sushant.vanarse@innoserv.co.in");
    $mail->personalization[0]->addCC($cc);

    $cc = new Email(null, "vivek.jain@innoserv.co.in");
    $mail->personalization[0]->addCC($cc);

    $cc = new Email(null, "renaissancelawcollegeindore@gmail.com");
    $mail->personalization[0]->addCC($cc);

    $apiKey = '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';
    $sg = new \SendGrid($apiKey);

    $request_body = $mail;
    $response = $sg->client->mail()->send()->post($request_body);

    include("../../db_config.php");

$insert_sql = "INSERT INTO renaissancelawcollege_lp_record (fname, mobile, email, city, program, query, lp_name, lp_link, form_name)
VALUES ('".$name."', '".$mobile."', '".$email."', '".$city."', '".$project."', '".$querymsg."', '".$lp_name."', '".$lp_link."', '".$form_name."')";

  if (mysqli_query($conn, $insert_sql)) {

  }
  
}
?>
